DROP TABLE Wine;
DROP TABLE Appelations;
DROP TABLE Grapes;