SELECT * FROM Wine;
SELECT COUNT(*) FROM Wine;
SELECT * FROM Appelations;
SELECT COUNT(*) FROM Appelations;
SELECT * FROM Grapes;
SELECT COUNT(*) FROM Grapes;


