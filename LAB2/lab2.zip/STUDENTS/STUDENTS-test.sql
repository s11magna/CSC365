SELECT * FROM teachers;
SELECT COUNT(*) FROM teachers;
SELECT * FROM List;
SELECT COUNT(*) FROM List;
