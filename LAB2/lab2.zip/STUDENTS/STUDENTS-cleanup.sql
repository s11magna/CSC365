DROP TABLE List;
DROP TABLE teachers;