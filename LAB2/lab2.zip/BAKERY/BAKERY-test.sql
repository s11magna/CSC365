SELECT * FROM Customers;
SELECT COUNT(*) FROM Customers;
SELECT * FROM Receipts;
SELECT COUNT(*) FROM Receipts;
SELECT * FROM Goods;
SELECT COUNT(*) FROM Goods;
SELECT * FROM Items;
SELECT COUNT(*) FROM Items;
