DROP TABLE Performance;
DROP TABLE Instruments;
DROP TABLE Vocals;
DROP TABLE Band;
DROP TABLE Tracklists;
DROP TABLE Albums;
DROP TABLE Songs;