INSERT INTO Albums(AID, TITLE, YEAR, LABEL) VALUES (1, 'Le Pop', 2008,'Propeller Recordings');
INSERT INTO Albums(AID, TITLE, YEAR, LABEL) VALUES (2, 'A Kiss Before You Go', 2011,'Propeller Recordings');
INSERT INTO Albums(AID, TITLE, YEAR, LABEL) VALUES (3, 'A Kiss Before You Go: Live in Hamburg', 2012,'Universal Music Group');
INSERT INTO Albums(AID, TITLE, YEAR, LABEL) VALUES (4, 'Rockland', 2015,'Propeller Recordings');
