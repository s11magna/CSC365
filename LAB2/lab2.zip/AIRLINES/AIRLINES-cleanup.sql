DROP TABLE Flights;
DROP TABLE Airports100;
DROP TABLE Airlines;